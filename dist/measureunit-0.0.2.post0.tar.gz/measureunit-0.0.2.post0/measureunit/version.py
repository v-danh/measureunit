# version number

__version_info__ = (0, 0, 2, 'post0')
__version__ = ".".join(str(i) for i in __version_info__)
# print(__version__)
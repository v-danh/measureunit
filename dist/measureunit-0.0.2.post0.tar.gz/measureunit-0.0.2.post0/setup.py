from setuptools import find_packages, setup
from measureunit.version import __version__

with open('README.md', 'r') as f:
    long_description = f.read()

setup(
    name='measureunit',
    version=__version__,
    description='A Python library of the measurement conversion',
    package_dir={'': 'measureunit'},
    packages=find_packages(where='measureunit'),
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/v-danh/measureunit',
    author='v.d.anh',
    license='MIT',
    classifiers=[
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
    extras_require={
        'dev': ['pytest>=7.0', 'twine>=4.0.2'],
    },
    python_requires='>=3',
)